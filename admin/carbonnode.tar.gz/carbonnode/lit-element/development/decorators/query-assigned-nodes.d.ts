/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
export * from '@lit/reactive-element/decorators/query-assigned-nodes.js';
//# sourceMappingURL=query-assigned-nodes.d.ts.map