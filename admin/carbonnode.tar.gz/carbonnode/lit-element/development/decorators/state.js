/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
export * from '@lit/reactive-element/decorators/state.js';
//# sourceMappingURL=state.js.map