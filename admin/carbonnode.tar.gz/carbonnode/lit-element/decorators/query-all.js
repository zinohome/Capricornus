export*from"@lit/reactive-element/decorators/query-all.js";
//# sourceMappingURL=query-all.js.map
