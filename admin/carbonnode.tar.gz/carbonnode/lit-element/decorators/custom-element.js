export*from"@lit/reactive-element/decorators/custom-element.js";
//# sourceMappingURL=custom-element.js.map
