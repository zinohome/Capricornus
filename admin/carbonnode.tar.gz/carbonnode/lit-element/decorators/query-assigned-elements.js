export*from"@lit/reactive-element/decorators/query-assigned-elements.js";
//# sourceMappingURL=query-assigned-elements.js.map
